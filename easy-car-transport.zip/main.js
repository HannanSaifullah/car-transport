(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./0hsmjqf5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0hsmjqf5.entry.js",
		2,
		"common",
		132
	],
	"./0hsmjqf5.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0hsmjqf5.sc.entry.js",
		2,
		"common",
		133
	],
	"./0utrggve.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0utrggve.entry.js",
		"common",
		58
	],
	"./0utrggve.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0utrggve.sc.entry.js",
		"common",
		59
	],
	"./1kttiagf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1kttiagf.entry.js",
		0,
		"common",
		134
	],
	"./1kttiagf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1kttiagf.sc.entry.js",
		0,
		"common",
		135
	],
	"./2g1gy9f9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2g1gy9f9.entry.js",
		"common",
		10
	],
	"./2g1gy9f9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2g1gy9f9.sc.entry.js",
		"common",
		11
	],
	"./4m739wpj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4m739wpj.entry.js",
		"common",
		60
	],
	"./4m739wpj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4m739wpj.sc.entry.js",
		"common",
		61
	],
	"./5ey3bs99.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ey3bs99.entry.js",
		"common",
		12
	],
	"./5ey3bs99.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ey3bs99.sc.entry.js",
		"common",
		13
	],
	"./5u5c8wcw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5u5c8wcw.entry.js",
		0,
		"common",
		136
	],
	"./5u5c8wcw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5u5c8wcw.sc.entry.js",
		0,
		"common",
		137
	],
	"./6dsdnxyn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6dsdnxyn.entry.js",
		"common",
		62
	],
	"./6dsdnxyn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6dsdnxyn.sc.entry.js",
		"common",
		63
	],
	"./6eqoprbr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6eqoprbr.entry.js",
		0,
		"common",
		138
	],
	"./6eqoprbr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6eqoprbr.sc.entry.js",
		0,
		"common",
		139
	],
	"./6g4thfnt.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6g4thfnt.entry.js",
		0,
		"common",
		114
	],
	"./6g4thfnt.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6g4thfnt.sc.entry.js",
		0,
		"common",
		115
	],
	"./8q1e6dus.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8q1e6dus.entry.js",
		"common",
		14
	],
	"./8q1e6dus.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8q1e6dus.sc.entry.js",
		"common",
		15
	],
	"./a7z8hams.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/a7z8hams.entry.js",
		"common",
		16
	],
	"./a7z8hams.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/a7z8hams.sc.entry.js",
		"common",
		17
	],
	"./adaxrxoq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/adaxrxoq.entry.js",
		"common",
		116
	],
	"./adaxrxoq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/adaxrxoq.sc.entry.js",
		"common",
		117
	],
	"./ao2edhxl.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ao2edhxl.entry.js",
		"common",
		18
	],
	"./ao2edhxl.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ao2edhxl.sc.entry.js",
		"common",
		19
	],
	"./av1nxhcg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/av1nxhcg.entry.js",
		"common",
		20
	],
	"./av1nxhcg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/av1nxhcg.sc.entry.js",
		"common",
		21
	],
	"./b9hbg5md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b9hbg5md.entry.js",
		"common",
		64
	],
	"./b9hbg5md.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b9hbg5md.sc.entry.js",
		"common",
		65
	],
	"./bfxkhdio.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bfxkhdio.entry.js",
		"common",
		22
	],
	"./bfxkhdio.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bfxkhdio.sc.entry.js",
		"common",
		23
	],
	"./bneiwm8s.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bneiwm8s.entry.js",
		"common",
		24
	],
	"./bneiwm8s.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bneiwm8s.sc.entry.js",
		"common",
		25
	],
	"./bzgyi6uy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bzgyi6uy.entry.js",
		"common",
		26
	],
	"./bzgyi6uy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bzgyi6uy.sc.entry.js",
		"common",
		27
	],
	"./c2kiol1t.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c2kiol1t.entry.js",
		"common",
		28
	],
	"./c2kiol1t.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c2kiol1t.sc.entry.js",
		"common",
		29
	],
	"./c3xilup3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c3xilup3.entry.js",
		"common",
		30
	],
	"./c3xilup3.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c3xilup3.sc.entry.js",
		"common",
		31
	],
	"./coytbtgb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/coytbtgb.entry.js",
		"common",
		72
	],
	"./coytbtgb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/coytbtgb.sc.entry.js",
		"common",
		73
	],
	"./cwd9g9my.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cwd9g9my.entry.js",
		"common",
		66
	],
	"./cwd9g9my.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cwd9g9my.sc.entry.js",
		"common",
		67
	],
	"./dlyuptke.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dlyuptke.entry.js",
		0,
		"common",
		142
	],
	"./dlyuptke.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dlyuptke.sc.entry.js",
		0,
		"common",
		143
	],
	"./dznymaqz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dznymaqz.entry.js",
		"common",
		74
	],
	"./dznymaqz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dznymaqz.sc.entry.js",
		"common",
		75
	],
	"./eljrbuqs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eljrbuqs.entry.js",
		"common",
		76
	],
	"./eljrbuqs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eljrbuqs.sc.entry.js",
		"common",
		77
	],
	"./ffukzwt6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ffukzwt6.entry.js",
		"common",
		124
	],
	"./ffukzwt6.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ffukzwt6.sc.entry.js",
		"common",
		125
	],
	"./fokfxvfn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fokfxvfn.entry.js",
		"common",
		68
	],
	"./fokfxvfn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fokfxvfn.sc.entry.js",
		"common",
		69
	],
	"./gwiqb6zv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gwiqb6zv.entry.js",
		"common",
		32
	],
	"./gwiqb6zv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gwiqb6zv.sc.entry.js",
		"common",
		33
	],
	"./hs4xwlox.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hs4xwlox.entry.js",
		"common",
		34
	],
	"./hs4xwlox.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hs4xwlox.sc.entry.js",
		"common",
		35
	],
	"./jdcptvrs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jdcptvrs.entry.js",
		"common",
		78
	],
	"./jdcptvrs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jdcptvrs.sc.entry.js",
		"common",
		79
	],
	"./jpkvsu5y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpkvsu5y.entry.js",
		"common",
		126
	],
	"./jpkvsu5y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpkvsu5y.sc.entry.js",
		"common",
		127
	],
	"./jtkjzkgg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jtkjzkgg.entry.js",
		"common",
		36
	],
	"./jtkjzkgg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jtkjzkgg.sc.entry.js",
		"common",
		37
	],
	"./jwqvpjte.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jwqvpjte.entry.js",
		"common",
		80
	],
	"./jwqvpjte.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jwqvpjte.sc.entry.js",
		"common",
		81
	],
	"./jzvvnvez.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jzvvnvez.entry.js",
		0,
		"common",
		144
	],
	"./jzvvnvez.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jzvvnvez.sc.entry.js",
		0,
		"common",
		145
	],
	"./l1m0sgjq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/l1m0sgjq.entry.js",
		"common",
		82
	],
	"./l1m0sgjq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/l1m0sgjq.sc.entry.js",
		"common",
		83
	],
	"./ladxfuum.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ladxfuum.entry.js",
		0,
		"common",
		146
	],
	"./ladxfuum.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ladxfuum.sc.entry.js",
		0,
		"common",
		147
	],
	"./ludl7zh0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ludl7zh0.entry.js",
		"common",
		38
	],
	"./ludl7zh0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ludl7zh0.sc.entry.js",
		"common",
		39
	],
	"./lwxjzkgx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lwxjzkgx.entry.js",
		0,
		"common",
		118
	],
	"./lwxjzkgx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lwxjzkgx.sc.entry.js",
		0,
		"common",
		119
	],
	"./ly8zbpmk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ly8zbpmk.entry.js",
		"common",
		40
	],
	"./ly8zbpmk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ly8zbpmk.sc.entry.js",
		"common",
		41
	],
	"./n5wnzrch.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n5wnzrch.entry.js",
		"common",
		70
	],
	"./n5wnzrch.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n5wnzrch.sc.entry.js",
		"common",
		71
	],
	"./neixdayp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/neixdayp.entry.js",
		"common",
		42
	],
	"./neixdayp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/neixdayp.sc.entry.js",
		"common",
		43
	],
	"./nr6wcehx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nr6wcehx.entry.js",
		"common",
		44
	],
	"./nr6wcehx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nr6wcehx.sc.entry.js",
		"common",
		45
	],
	"./o2g4txhh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/o2g4txhh.entry.js",
		"common",
		84
	],
	"./o2g4txhh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/o2g4txhh.sc.entry.js",
		"common",
		85
	],
	"./oboc8zd4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oboc8zd4.entry.js",
		"common",
		86
	],
	"./oboc8zd4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oboc8zd4.sc.entry.js",
		"common",
		87
	],
	"./odqmlmdd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/odqmlmdd.entry.js",
		"common",
		46
	],
	"./odqmlmdd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/odqmlmdd.sc.entry.js",
		"common",
		47
	],
	"./okpgrmbb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/okpgrmbb.entry.js",
		"common",
		48
	],
	"./okpgrmbb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/okpgrmbb.sc.entry.js",
		"common",
		49
	],
	"./pfpbfexy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pfpbfexy.entry.js",
		"common",
		88
	],
	"./pfpbfexy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pfpbfexy.sc.entry.js",
		"common",
		89
	],
	"./pubwd8xa.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pubwd8xa.entry.js",
		"common",
		90
	],
	"./pubwd8xa.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pubwd8xa.sc.entry.js",
		"common",
		91
	],
	"./qeoxaimy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qeoxaimy.entry.js",
		2,
		"common",
		148
	],
	"./qeoxaimy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qeoxaimy.sc.entry.js",
		2,
		"common",
		149
	],
	"./qrxqqhr4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qrxqqhr4.entry.js",
		"common",
		92
	],
	"./qrxqqhr4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qrxqqhr4.sc.entry.js",
		"common",
		93
	],
	"./qvwswew4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qvwswew4.entry.js",
		"common",
		120
	],
	"./qvwswew4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qvwswew4.sc.entry.js",
		"common",
		121
	],
	"./rsatbj4w.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rsatbj4w.entry.js",
		"common",
		94
	],
	"./rsatbj4w.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rsatbj4w.sc.entry.js",
		"common",
		95
	],
	"./soeaphrm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/soeaphrm.entry.js",
		0,
		"common",
		150
	],
	"./soeaphrm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/soeaphrm.sc.entry.js",
		0,
		"common",
		151
	],
	"./sqd5wawk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sqd5wawk.entry.js",
		0,
		"common",
		152
	],
	"./sqd5wawk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sqd5wawk.sc.entry.js",
		0,
		"common",
		153
	],
	"./sw2yobif.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sw2yobif.entry.js",
		"common",
		50
	],
	"./sw2yobif.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sw2yobif.sc.entry.js",
		"common",
		51
	],
	"./t547wlk7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/t547wlk7.entry.js",
		"common",
		122
	],
	"./t547wlk7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/t547wlk7.sc.entry.js",
		"common",
		123
	],
	"./tluindqz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tluindqz.entry.js",
		0,
		"common",
		154
	],
	"./tluindqz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tluindqz.sc.entry.js",
		0,
		"common",
		155
	],
	"./tpeqvzxx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tpeqvzxx.entry.js",
		"common",
		128
	],
	"./tpeqvzxx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tpeqvzxx.sc.entry.js",
		"common",
		129
	],
	"./tqgphjq7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tqgphjq7.entry.js",
		"common",
		52
	],
	"./tqgphjq7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tqgphjq7.sc.entry.js",
		"common",
		53
	],
	"./tylmm2yl.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tylmm2yl.entry.js",
		"common",
		96
	],
	"./tylmm2yl.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tylmm2yl.sc.entry.js",
		"common",
		97
	],
	"./ucdtgfa9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ucdtgfa9.entry.js",
		0,
		"common",
		156
	],
	"./ucdtgfa9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ucdtgfa9.sc.entry.js",
		0,
		"common",
		157
	],
	"./uegz8gm3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uegz8gm3.entry.js",
		"common",
		98
	],
	"./uegz8gm3.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uegz8gm3.sc.entry.js",
		"common",
		99
	],
	"./uetn90ud.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uetn90ud.entry.js",
		"common",
		100
	],
	"./uetn90ud.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uetn90ud.sc.entry.js",
		"common",
		101
	],
	"./vbsrxypz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vbsrxypz.entry.js",
		158
	],
	"./vbsrxypz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vbsrxypz.sc.entry.js",
		159
	],
	"./vtbkki9o.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vtbkki9o.entry.js",
		"common",
		102
	],
	"./vtbkki9o.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vtbkki9o.sc.entry.js",
		"common",
		103
	],
	"./vxxpn0fi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vxxpn0fi.entry.js",
		0,
		"common",
		160
	],
	"./vxxpn0fi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vxxpn0fi.sc.entry.js",
		0,
		"common",
		161
	],
	"./wajpsmly.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wajpsmly.entry.js",
		"common",
		54
	],
	"./wajpsmly.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wajpsmly.sc.entry.js",
		"common",
		55
	],
	"./wsfvc8rr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wsfvc8rr.entry.js",
		"common",
		56
	],
	"./wsfvc8rr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wsfvc8rr.sc.entry.js",
		"common",
		57
	],
	"./x4ue4dpx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/x4ue4dpx.entry.js",
		0,
		"common",
		162
	],
	"./x4ue4dpx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/x4ue4dpx.sc.entry.js",
		0,
		"common",
		163
	],
	"./xgnma4yj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xgnma4yj.entry.js",
		"common",
		104
	],
	"./xgnma4yj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xgnma4yj.sc.entry.js",
		"common",
		105
	],
	"./xnfqzgvy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xnfqzgvy.entry.js",
		"common",
		106
	],
	"./xnfqzgvy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xnfqzgvy.sc.entry.js",
		"common",
		107
	],
	"./ycyyhg01.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ycyyhg01.entry.js",
		"common",
		108
	],
	"./ycyyhg01.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ycyyhg01.sc.entry.js",
		"common",
		109
	],
	"./ye5age0r.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ye5age0r.entry.js",
		164
	],
	"./ye5age0r.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ye5age0r.sc.entry.js",
		165
	],
	"./yxulgzjp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yxulgzjp.entry.js",
		"common",
		110
	],
	"./yxulgzjp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yxulgzjp.sc.entry.js",
		"common",
		111
	],
	"./z9nt6ntd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9nt6ntd.entry.js",
		"common",
		130
	],
	"./z9nt6ntd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9nt6ntd.sc.entry.js",
		"common",
		131
	],
	"./zdhyxh0f.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zdhyxh0f.entry.js",
		"common",
		112
	],
	"./zdhyxh0f.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zdhyxh0f.sc.entry.js",
		"common",
		113
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"../home/home.module": [
		"./src/app/home/home.module.ts",
		"home-home-module"
	],
	"./tabs/tabs.module": [
		"./src/app/tabs/tabs.module.ts",
		"tabs-tabs-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return __webpack_require__.e(ids[1]).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    { path: '', loadChildren: './tabs/tabs.module#TabsPageModule' }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"], onSameUrlNavigation: 'reload' })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\r\n  <!-- <ion-split-pane>\r\n    <ion-menu>\r\n      <ion-header>\r\n        <ion-toolbar>\r\n          <ion-title>Menu</ion-title>\r\n          \r\n          <ion-item  lines=\"none\" slot=\"end\" ><img src=\"../assets/icon/logo32x32.png\"/></ion-item>\r\n\r\n        </ion-toolbar>\r\n\r\n      </ion-header>\r\n      <ion-content>\r\n        <ion-list>\r\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of menuPages\">\r\n            <ion-item lines=\"none\" [routerDirection]=\"'root'\" [routerLink]=\"[p.url]\">\r\n              <ion-icon slot=\"start\" [name]=\"p.icon\"></ion-icon>\r\n              <ion-label>\r\n                {{p.title}}\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-menu-toggle>\r\n        </ion-list>\r\n      </ion-content>\r\n    </ion-menu>\r\n    <ion-router-outlet main></ion-router-outlet>\r\n  </ion-split-pane> -->\r\n  <ion-router-outlet></ion-router-outlet>\r\n</ion-app>"

/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-auto-complete {\n  width: 50vw; }\n\n.s-ion-icon {\n  fill: #00342c; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvRDpcXFByb2plY3RzXFxjYXItdHJhbnNwb3J0LWZyb250ZW5kL3NyY1xcYXBwXFxhcHAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFXLEVBQUE7O0FBR2Y7RUFDSSxhQUFhLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9hcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tYXV0by1jb21wbGV0ZSB7XHJcbiAgICB3aWR0aDogNTB2dztcclxuICB9XHJcbiAgXHJcbi5zLWlvbi1pY29uIHtcclxuICAgIGZpbGw6ICMwMDM0MmM7XHJcbiAgICB9Il19 */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/background-mode/ngx */ "./node_modules/@ionic-native/background-mode/ngx/index.js");






var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar, backgroundMode) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.backgroundMode = backgroundMode;
        this.menuPages = [
            {
                title: 'Calendar',
                url: '/calendar',
                icon: 'calendar'
            },
            {
                title: 'Timings',
                url: '/timing',
                icon: 'time'
            }
        ];
        this.initializeApp();
        this.backgroundMode.enable();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
        });
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"],
            _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_5__["BackgroundMode"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _ionic_native_media_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/media/ngx */ "./node_modules/@ionic-native/media/ngx/index.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/service-worker */ "./node_modules/@angular/service-worker/fesm5/service-worker.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/background-mode/ngx */ "./node_modules/@ionic-native/background-mode/ngx/index.js");
/* harmony import */ var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/local-notifications/ngx */ "./node_modules/@ionic-native/local-notifications/ngx/index.js");
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/components.module */ "./src/app/components/components.module.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var ionic4_auto_complete__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ionic4-auto-complete */ "./node_modules/ionic4-auto-complete/fesm5/ionic4-auto-complete.js");

















var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"]],
            imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpClientModule"],
                _components_components_module__WEBPACK_IMPORTED_MODULE_14__["ComponentModule"], ionic4_auto_complete__WEBPACK_IMPORTED_MODULE_16__["AutoCompleteModule"],
                _angular_service_worker__WEBPACK_IMPORTED_MODULE_10__["ServiceWorkerModule"].register('ngsw-worker.js', { enabled: _environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].production })],
            providers: [
                _ionic_native_media_ngx__WEBPACK_IMPORTED_MODULE_7__["Media"],
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
                _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_12__["BackgroundMode"],
                _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_13__["LocalNotifications"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/components/components.module.ts":
/*!*************************************************!*\
  !*** ./src/app/components/components.module.ts ***!
  \*************************************************/
/*! exports provided: ComponentModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComponentModule", function() { return ComponentModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./header/header.component */ "./src/app/components/header/header.component.ts");





var ComponentModule = /** @class */ (function () {
    function ComponentModule() {
    }
    ComponentModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            ],
            declarations: [_header_header_component__WEBPACK_IMPORTED_MODULE_4__["HeaderComponent"]],
            exports: [_header_header_component__WEBPACK_IMPORTED_MODULE_4__["HeaderComponent"]]
        })
    ], ComponentModule);
    return ComponentModule;
}());



/***/ }),

/***/ "./src/app/components/header/header.component.html":
/*!*********************************************************!*\
  !*** ./src/app/components/header/header.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n    <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n        <ion-menu-button></ion-menu-button>\r\n      </ion-buttons>\r\n      <ion-title>\r\n         {{title}}\r\n      </ion-title>\r\n      <!-- <ion-buttons slot=\"end\">\r\n        <ion-icon class=\"m-2\" (click)=\"settings()\" name=\"settings\" style=\"zoom:1.5;\"></ion-icon>\r\n      </ion-buttons> -->\r\n    </ion-toolbar>\r\n  </ion-header>\r\n  "

/***/ }),

/***/ "./src/app/components/header/header.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/components/header/header.component.ts ***!
  \*******************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var HeaderComponent = /** @class */ (function () {
    function HeaderComponent() {
    }
    HeaderComponent.prototype.settings = function () {
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], HeaderComponent.prototype, "title", void 0);
    HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/components/header/header.component.html"),
        })
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    // baseUrl: 'http://localhost:5000/'
    baseUrl: 'http://ec2-3-128-27-118.us-east-2.compute.amazonaws.com:5000/'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\Projects\car-transport-frontend\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map