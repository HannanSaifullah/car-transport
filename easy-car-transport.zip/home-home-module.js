(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./src/app/config/config.sevice.ts":
/*!*****************************************!*\
  !*** ./src/app/config/config.sevice.ts ***!
  \*****************************************/
/*! exports provided: ConfigService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigService", function() { return ConfigService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");




var ConfigService = /** @class */ (function () {
    function ConfigService(http) {
        this.http = http;
    }
    ConfigService.prototype.calculate = function (data) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].baseUrl + "api/city/enquiery", data);
    };
    ConfigService.prototype.getCars = function () {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].baseUrl + "api/car");
    };
    ConfigService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], ConfigService);
    return ConfigService;
}());



/***/ }),

/***/ "./src/app/home/filterSuburbService.ts":
/*!*********************************************!*\
  !*** ./src/app/home/filterSuburbService.ts ***!
  \*********************************************/
/*! exports provided: FilterSuburbService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilterSuburbService", function() { return FilterSuburbService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");





var FilterSuburbService = /** @class */ (function () {
    function FilterSuburbService(http) {
        this.http = http;
        this.formValueAttribute = "";
    }
    FilterSuburbService.prototype.getResults = function (keyword) {
        if (!keyword) {
            return false;
        }
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].baseUrl + 'api/suburb').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (result) {
            var filteredSuburbs = result.payload.filter(function (item) {
                return (item.name && item.name.toLowerCase().includes(keyword.toLowerCase()) || item.postal_code && item.postal_code == keyword || item.zone && item.zone.includes(keyword));
            });
            console.log(filteredSuburbs);
            return filteredSuburbs;
        }));
    };
    // getResults(keyword:string) {
    //   return this.http.get("http://localhost:5000/api/suburb").subscribe(
    //       (result:any) =>
    //       {
    //         const filteredSuburbs =  result.payload
    //           .filter(item => item.name && item.name.toLowerCase().includes(keyword.toLowerCase()));
    //           console.log(filteredSuburbs.length);
    //           return filteredSuburbs;
    //       });
    // }
    FilterSuburbService.prototype.getItemLabel = function (suburb) {
        return suburb.name ? suburb.postal_code + ' - ' + suburb.name : '';
    };
    FilterSuburbService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], FilterSuburbService);
    return FilterSuburbService;
}());



/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var ionic4_auto_complete__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ionic4-auto-complete */ "./node_modules/ionic4-auto-complete/fesm5/ionic4-auto-complete.js");
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/components.module */ "./src/app/components/components.module.ts");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");
/* harmony import */ var _config_config_sevice__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../config/config.sevice */ "./src/app/config/config.sevice.ts");
/* harmony import */ var _filterSuburbService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./filterSuburbService */ "./src/app/home/filterSuburbService.ts");











var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentModule"],
                ionic4_auto_complete__WEBPACK_IMPORTED_MODULE_6__["AutoCompleteModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([
                    { path: '',
                        component: _home_page__WEBPACK_IMPORTED_MODULE_8__["HomePage"] }
                ])
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_8__["HomePage"]],
            providers: [_config_config_sevice__WEBPACK_IMPORTED_MODULE_9__["ConfigService"], _filterSuburbService__WEBPACK_IMPORTED_MODULE_10__["FilterSuburbService"]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/home/home.page.html":
/*!*************************************!*\
  !*** ./src/app/home/home.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <app-header title=\"Home\"></app-header> -->\r\n\r\n<ion-header [translucent]=\"true\">\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title> Easy Car Transport </ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content class=\"main-container\">\r\n  <!-- <ion-header collapse=\"condense\">\r\n      <ion-toolbar>\r\n        <ion-title size=\"large\">{{ folder }}</ion-title>\r\n      </ion-toolbar>\r\n    </ion-header> -->\r\n\r\n  <!-- <img class=\"background-image\" src=\"../../assets//images/car-transport.jpg\" /> -->\r\n  <ion-card class=\"get-quote\">\r\n    <ion-card-title class=\"title\"> Transport the vehicle all over Australia with ease</ion-card-title>\r\n    <div class=\"get-quote-form ion-padding-vertical \">\r\n      <form #myForm=\"ngForm\">\r\n        <ion-grid class=\"\">\r\n          <!-- <ion-col class=\"place-selection\"> -->\r\n          <ng-template #empty let-attrs=\"attrs\">\r\n            <ion-text>Sorry, Suburb Not found</ion-text>\r\n          </ng-template>\r\n          <ng-template #withPostalCode let-attrs=\"attrs\">\r\n            {{attrs.data.postal_code | boldprefix:attrs.keyword}} -\r\n            <span [innerHTML]=\"attrs.data.name | boldprefix:attrs.keyword\"></span>\r\n          </ng-template>\r\n          <!-- <ion-row class=\"ion-padding-horizontal ion-justify-content-center\"> -->\r\n          <ion-auto-complete [dataProvider]=\"filterSuburbService\" [(ngModel)]=\"from\" name=\"from\" [useIonInput]=\"false\"\r\n            [showResultsFirst]=\"true\" [multi]=\"false\" [options]=\"fromOptions\" [emptyTemplate]=\"empty\"\r\n            (itemSelected)=\"fromItemSelected($event)\"></ion-auto-complete>\r\n          <ion-auto-complete [dataProvider]=\"filterSuburbService\" [(ngModel)]=\"to\" name=\"to\" [useIonInput]=\"false\"\r\n            [showResultsFirst]=\"true\" [multi]=\"false\" [options]=\"toOptions\" [emptyTemplate]=\"empty\"\r\n            (itemSelected)=\"toItemSelected($event)\"></ion-auto-complete>\r\n          <!-- [template]=\"withPostalCode\" -->\r\n\r\n          <ion-select placeholder=\"Select Car\" [(ngModel)]=\"car\" name=\"car\" >\r\n            <ion-select-option *ngFor=\"let car of cars\" [value]=\"car._id\">{{car.name}}</ion-select-option>\r\n          </ion-select>\r\n          <!-- </ion-row> -->\r\n          <ion-row class=\"ion-padding-top ion-justify-content-center\">\r\n            <ion-checkbox color=\"primary\" name=\"modifications\" disabled></ion-checkbox>\r\n            <ion-label class=\"ion-padding-horizontal\"  color=\"primary\">Modifications</ion-label>\r\n          </ion-row>\r\n          <!-- </ion-col> -->\r\n\r\n          <ion-datetime displayFormat=\"MM/DD/YYYY\" pickerFormat=\"MM/DD/YYYY\" placeholder=\"Select a Date\" value=\"\"\r\n            display-timezone=\"utc\" [(ngModel)]=\"date\" name=\"date\">\r\n          </ion-datetime>\r\n          <ion-input placeholder=\"Enter Email\"  [(ngModel)]=\"email\"  pattern=\"[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}\" type=\"email\" name=\"emailText\" #emailText=\"ngModel\"></ion-input>\r\n          <span class=\"ion-text-sm text-danger\" *ngIf=\"emailText.errors?.pattern\" >Please enter valid Email address</span>\r\n\r\n          <ion-row class=\"ion-padding-top ion-justify-content-center ion-align-item-center\">\r\n            <ion-checkbox color=\"primary\" [(ngModel)]=\"tAndC\" name=\"tAndC\"></ion-checkbox>\r\n            <ion-label class=\"ion-padding-horizontal\" color=\"primary\">I agree to the terms & conditions</ion-label>\r\n          </ion-row>\r\n          <ion-row class=\"ion-padding-top ion-justify-content-center\">\r\n            <ion-button color=\"danger\" (click)=\"calculate()\" [disabled]=\"!tAndC || !email || !date || !car || !from || !to || emailText.errors?.pattern \">Calculate</ion-button>\r\n          </ion-row>\r\n          <ion-text class=\"ion-text-sm text-danger\">**All fields are required for Enquiry</ion-text>\r\n        </ion-grid>\r\n      </form>\r\n    </div>\r\n  </ion-card>\r\n  <!-- <p>Explore <a target=\"_blank\" rel=\"noopener noreferrer\" href=\"https://ionicframework.com/docs/components\">UI Components</a></p> -->\r\n</ion-content>"

/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-menu-button {\n  color: var(--ion-color-primary); }\n\n.main-container {\n  text-align: center;\n  left: 0;\n  right: 0; }\n\n.main-container .get-quote {\n    background-color: #d9d9f7;\n    --ion-background-color: rgb(217, 217, 247); }\n\n.main-container .get-quote .title {\n      padding: 10px 10px 0 10px;\n      color: red; }\n\n.main-container .get-quote .get-quote-form {\n      color: #000000; }\n\n.main-container .get-quote .get-quote-form ion-grid {\n        display: flex;\n        align-items: center;\n        flex-direction: column; }\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px; }\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0; }\n\n#container a {\n  text-decoration: none; }\n\n/* Set the width to the full container and center the content */\n\nion-select, ion-searchbar, ion-input, ion-datetime {\n  margin-top: 10px;\n  background-color: #fff;\n  --ion-background-color: #fff;\n  justify-content: center;\n  border-radius: 2px;\n  width: 60%; }\n\nion-searchbar input {\n  background-color: #fff; }\n\n.place-selection ion-select, ion-searchbar {\n  width: 30%; }\n\n/* Set the flex in order to size the text width to its content */\n\nion-select::part(placeholder),\nion-select::part(text) {\n  flex: 0 0 auto; }\n\n/* Set the placeholder color and opacity */\n\nion-select::part(placeholder) {\n  color: grey;\n  opacity: 1; }\n\n/* Set the text color */\n\nion-select::part(text) {\n  color: black; }\n\n/* Set the icon color and opacity */\n\nion-select::part(icon) {\n  color: black;\n  opacity: 1; }\n\n.autocomplete {\n  width: 100%; }\n\n.autocomplete ion-searchbar {\n    padding: 1px !important; }\n\n.autocomplete ion-list {\n    position: absolute;\n    width: inherit;\n    overflow-y: scroll;\n    max-height: 150%;\n    z-index: 999; }\n\n.autocomplete ion-list ion-item img {\n      max-height: 2.5rem;\n      width: auto;\n      margin: auto;\n      display: block; }\n\n.autocomplete ion-list ion-item:hover {\n      cursor: pointer;\n      background: #f1f1f1; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9EOlxcUHJvamVjdHNcXGNhci10cmFuc3BvcnQtZnJvbnRlbmQvc3JjXFxhcHBcXGhvbWVcXGhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksK0JBQStCLEVBQUE7O0FBR2pDO0VBQ0Usa0JBQWtCO0VBQ2xCLE9BQU87RUFDUCxRQUFRLEVBQUE7O0FBSFY7SUFRSSx5QkFBb0M7SUFDckMsMENBQXVCLEVBQUE7O0FBVDFCO01BY00seUJBQTBCO01BQzFCLFVBQVUsRUFBQTs7QUFmaEI7TUF1Qk0sY0FBYyxFQUFBOztBQXZCcEI7UUFtQlEsYUFBYTtRQUNiLG1CQUFtQjtRQUNuQixzQkFBc0IsRUFBQTs7QUFPOUI7RUFDRSxlQUFlO0VBQ2YsaUJBQWlCLEVBQUE7O0FBR25CO0VBQ0UsZUFBZTtFQUNmLGlCQUFpQjtFQUNqQixjQUFjO0VBQ2QsU0FBUyxFQUFBOztBQUdYO0VBQ0UscUJBQXFCLEVBQUE7O0FBR3ZCLCtEQUFBOztBQUNBO0VBQ0UsZ0JBQWdCO0VBQ2hCLHNCQUFzQjtFQUN0Qiw0QkFBdUI7RUFDdkIsdUJBQXVCO0VBQ3ZCLGtCQUFrQjtFQUNsQixVQUFVLEVBQUE7O0FBR1o7RUFDRSxzQkFBc0IsRUFBQTs7QUFJeEI7RUFDRSxVQUFVLEVBQUE7O0FBR1osZ0VBQUE7O0FBQ0E7O0VBRUUsY0FBYyxFQUFBOztBQUdoQiwwQ0FBQTs7QUFDQTtFQUNFLFdBQVc7RUFDWCxVQUFVLEVBQUE7O0FBR1osdUJBQUE7O0FBQ0E7RUFDRSxZQUFZLEVBQUE7O0FBR2QsbUNBQUE7O0FBQ0E7RUFDRSxZQUFZO0VBQ1osVUFBVSxFQUFBOztBQUdaO0VBQ0UsV0FBVyxFQUFBOztBQURiO0lBSUksdUJBQXVCLEVBQUE7O0FBSjNCO0lBUUksa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCxrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLFlBQVksRUFBQTs7QUFaaEI7TUFpQlEsa0JBQWtCO01BQ2xCLFdBQVc7TUFDWCxZQUFZO01BQ1osY0FBYyxFQUFBOztBQXBCdEI7TUF5Qk0sZUFBZTtNQUNmLG1CQUNGLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9ob21lL2hvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmlvbi1tZW51LWJ1dHRvbiB7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gIH1cclxuICBcclxuICAubWFpbi1jb250YWluZXIge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgbGVmdDogMDtcclxuICAgIHJpZ2h0OiAwO1xyXG4gICAgLy8gdG9wOiA1MCU7XHJcbiAgICAvLyB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XHJcbiAgICAvLyBiYWNrZ3JvdW5kOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1hZ2VzL2Nhci10cmFuc3BvcnQuanBnXCIpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIGZpeGVkO1xyXG4gICAgLmdldC1xdW90ZSB7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyMTcsIDIxNywgMjQ3KTtcclxuICAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjE3LCAyMTcsIDI0Nyk7XHJcbiAgICAvLyAgIG9wYWNpdHk6IDAuNztcclxuICAgIC8vICAgYmFja2dyb3VuZC1jb2xvcjogI2Q0ZTFlYjtcclxuICAgIC8vICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KDMxNWRlZywgIzU2N2RmZCAwJSwgIzAwMDAwMCA3NCUpO1xyXG4gICAgICAudGl0bGUge1xyXG4gICAgICAgIHBhZGRpbmc6ICAxMHB4IDEwcHggMCAxMHB4O1xyXG4gICAgICAgIGNvbG9yOiByZWQ7XHJcbiAgICAgIH1cclxuICAgICAgLmdldC1xdW90ZS1mb3JtIHtcclxuICAgICAgICBpb24tZ3JpZCB7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbG9yOiAjMDAwMDAwO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIFxyXG4gICNjb250YWluZXIgc3Ryb25nIHtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyNnB4O1xyXG4gIH1cclxuICBcclxuICAjY29udGFpbmVyIHAge1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XHJcbiAgICBjb2xvcjogIzhjOGM4YztcclxuICAgIG1hcmdpbjogMDtcclxuICB9XHJcbiAgXHJcbiAgI2NvbnRhaW5lciBhIHtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICB9XHJcbiAgXHJcbiAgLyogU2V0IHRoZSB3aWR0aCB0byB0aGUgZnVsbCBjb250YWluZXIgYW5kIGNlbnRlciB0aGUgY29udGVudCAqL1xyXG4gIGlvbi1zZWxlY3QsaW9uLXNlYXJjaGJhcixpb24taW5wdXQsIGlvbi1kYXRldGltZSB7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDJweDtcclxuICAgIHdpZHRoOiA2MCU7XHJcbiAgfVxyXG5cclxuICBpb24tc2VhcmNoYmFyIGlucHV0IHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgfVxyXG4gIFxyXG4gIFxyXG4gIC5wbGFjZS1zZWxlY3Rpb24gaW9uLXNlbGVjdCwgaW9uLXNlYXJjaGJhciB7XHJcbiAgICB3aWR0aDogMzAlO1xyXG4gIH1cclxuICBcclxuICAvKiBTZXQgdGhlIGZsZXggaW4gb3JkZXIgdG8gc2l6ZSB0aGUgdGV4dCB3aWR0aCB0byBpdHMgY29udGVudCAqL1xyXG4gIGlvbi1zZWxlY3Q6OnBhcnQocGxhY2Vob2xkZXIpLFxyXG4gIGlvbi1zZWxlY3Q6OnBhcnQodGV4dCkge1xyXG4gICAgZmxleDogMCAwIGF1dG87XHJcbiAgfVxyXG4gIFxyXG4gIC8qIFNldCB0aGUgcGxhY2Vob2xkZXIgY29sb3IgYW5kIG9wYWNpdHkgKi9cclxuICBpb24tc2VsZWN0OjpwYXJ0KHBsYWNlaG9sZGVyKSB7XHJcbiAgICBjb2xvcjogZ3JleTtcclxuICAgIG9wYWNpdHk6IDE7XHJcbiAgfVxyXG4gIFxyXG4gIC8qIFNldCB0aGUgdGV4dCBjb2xvciAqL1xyXG4gIGlvbi1zZWxlY3Q6OnBhcnQodGV4dCkge1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gIH1cclxuICBcclxuICAvKiBTZXQgdGhlIGljb24gY29sb3IgYW5kIG9wYWNpdHkgKi9cclxuICBpb24tc2VsZWN0OjpwYXJ0KGljb24pIHtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIG9wYWNpdHk6IDE7XHJcbiAgfVxyXG4gIFxyXG4gIC5hdXRvY29tcGxldGUge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgXHJcbiAgICBpb24tc2VhcmNoYmFyIHtcclxuICAgICAgcGFkZGluZzogMXB4ICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgXHJcbiAgICBpb24tbGlzdCB7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgd2lkdGg6IGluaGVyaXQ7XHJcbiAgICAgIG92ZXJmbG93LXk6IHNjcm9sbDtcclxuICAgICAgbWF4LWhlaWdodDogMTUwJTtcclxuICAgICAgei1pbmRleDogOTk5O1xyXG4gIFxyXG4gICAgICBpb24taXRlbSB7XHJcbiAgXHJcbiAgICAgICAgaW1nIHtcclxuICAgICAgICAgIG1heC1oZWlnaHQ6IDIuNXJlbTtcclxuICAgICAgICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgICAgICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgXHJcbiAgICAgIGlvbi1pdGVtOmhvdmVyIHtcclxuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2YxZjFmMVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSJdfQ== */"

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var ionic4_auto_complete__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ionic4-auto-complete */ "./node_modules/ionic4-auto-complete/fesm5/ionic4-auto-complete.js");
/* harmony import */ var _config_config_sevice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../config/config.sevice */ "./src/app/config/config.sevice.ts");
/* harmony import */ var _filterSuburbService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./filterSuburbService */ "./src/app/home/filterSuburbService.ts");





var HomePage = /** @class */ (function () {
    function HomePage(service, filterSuburbService) {
        this.service = service;
        this.filterSuburbService = filterSuburbService;
        this.suburbs = [];
        this.cars = [];
        this.filteredSuburbs = [];
        this.tAndC = false;
        this.options = new ionic4_auto_complete__WEBPACK_IMPORTED_MODULE_2__["AutoCompleteOptions"]();
        this.options.mode = 'md';
        this.options.autocomplete = 'on';
        this.options.debounce = 150;
        this.options.placeholder = 'Type text to search..';
        this.fromOptions = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this.options, { placeholder: 'From' });
        this.toOptions = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this.options, { placeholder: 'To' });
    }
    HomePage.prototype.ngOnInit = function () {
        this.getCars();
    };
    HomePage.prototype.getCars = function () {
        var _this = this;
        this.service.getCars().subscribe(function (res) {
            _this.cars = res.payload;
        });
    };
    HomePage.prototype.searchFromSuburb = function (searchValue) {
        console.log(searchValue);
        console.log("===================");
        this.filteredSuburbs = this.suburbs.filter(function (res) { return (res.name && res.name.toLowerCase().includes(searchValue)) || (res.postal_code && res.postal_code === searchValue) || (res.zone && res.zone === searchValue); });
        console.log(this.filteredSuburbs);
    };
    HomePage.prototype.fromItemSelected = function (object) {
        this.from = object;
    };
    HomePage.prototype.toItemSelected = function (object) {
        this.to = object;
    };
    HomePage.prototype.calculate = function () {
        var _this = this;
        var postData = {
            fromSuburb: this.from._id,
            toSuburb: this.to._id,
            car: this.car,
            date: this.date,
            email: this.email
        };
        this.service.calculate(postData).subscribe(function (res) {
            _this.resetForm();
            // this.suburbs = res.payload;
            // this.filteredSuburbs = this.suburbs;
        });
    };
    HomePage.prototype.resetForm = function () {
        this.from = {};
        this.to = {};
        this.car = null;
        this.date = null;
        this.email = null;
    };
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.page.html */ "./src/app/home/home.page.html"),
            styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_config_config_sevice__WEBPACK_IMPORTED_MODULE_3__["ConfigService"], _filterSuburbService__WEBPACK_IMPORTED_MODULE_4__["FilterSuburbService"]])
    ], HomePage);
    return HomePage;
}());



/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map